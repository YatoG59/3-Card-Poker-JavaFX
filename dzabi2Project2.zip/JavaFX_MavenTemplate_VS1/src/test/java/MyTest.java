import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import java.util.ArrayList;

public class MyTest {
    private Deck deck;
    private Dealer dealer;
    private ArrayList<Card> hand1;
    private ArrayList<Card> hand2;

    @BeforeEach
    void setUp() {
        deck = new Deck();
        dealer = new Dealer();
        hand1 = new ArrayList<>();
        hand2 = new ArrayList<>();
    }

    // ThreeCardLogic Tests

    @Test
    void testStraightFlush() {
        hand1.add(new Card("hearts", "2"));
        hand1.add(new Card("hearts", "3"));
        hand1.add(new Card("hearts", "4"));
        assertEquals(1, ThreeCardLogic.evaluateHand(hand1));
    }

    @Test
    void testThreeOfAKind() {
        hand1.add(new Card("hearts", "king"));
        hand1.add(new Card("diamonds", "king"));
        hand1.add(new Card("clubs", "king"));
        assertEquals(2, ThreeCardLogic.evaluateHand(hand1));
    }

    @Test
    void testStraight() {
        hand1.add(new Card("hearts", "7"));
        hand1.add(new Card("diamonds", "8"));
        hand1.add(new Card("clubs", "9"));
        assertEquals(3, ThreeCardLogic.evaluateHand(hand1));
    }

    @Test
    void testFlush() {
        hand1.add(new Card("hearts", "2"));
        hand1.add(new Card("hearts", "5"));
        hand1.add(new Card("hearts", "9"));
        assertEquals(4, ThreeCardLogic.evaluateHand(hand1));
    }

    @Test
    void testPair() {
        hand1.add(new Card("hearts", "queen"));
        hand1.add(new Card("diamonds", "queen"));
        hand1.add(new Card("clubs", "5"));
        assertEquals(5, ThreeCardLogic.evaluateHand(hand1));
    }

    @Test
    void testHighCard() {
        hand1.add(new Card("hearts", "king"));
        hand1.add(new Card("diamonds", "7"));
        hand1.add(new Card("clubs", "2"));
        assertEquals(6, ThreeCardLogic.evaluateHand(hand1));
    }

    @Test
    void testAceLowStraight() {
        hand1.add(new Card("hearts", "ace"));
        hand1.add(new Card("diamonds", "2"));
        hand1.add(new Card("clubs", "3"));
        assertEquals(3, ThreeCardLogic.evaluateHand(hand1));
    }

    @Test
    void testAceHighStraight() {
        hand1.add(new Card("hearts", "king"));
        hand1.add(new Card("diamonds", "queen"));
        hand1.add(new Card("clubs", "ace"));
        assertEquals(3, ThreeCardLogic.evaluateHand(hand1));
    }

    @Test
    void testStraightFlushAceLow() {
        hand1.add(new Card("hearts", "ace"));
        hand1.add(new Card("hearts", "2"));
        hand1.add(new Card("hearts", "3"));
        assertEquals(1, ThreeCardLogic.evaluateHand(hand1));
    }

    @Test
    void testStraightFlushAceHigh() {
        hand1.add(new Card("hearts", "king"));
        hand1.add(new Card("hearts", "queen"));
        hand1.add(new Card("hearts", "ace"));
        assertEquals(1, ThreeCardLogic.evaluateHand(hand1));
    }

    @Test
    void testCompareHandsStraightFlushVsThreeOfAKind() {
        // Straight Flush
        hand1.add(new Card("hearts", "2"));
        hand1.add(new Card("hearts", "3"));
        hand1.add(new Card("hearts", "4"));
        
        // Three of a Kind
        hand2.add(new Card("hearts", "king"));
        hand2.add(new Card("diamonds", "king"));
        hand2.add(new Card("clubs", "king"));
        
        assertTrue(ThreeCardLogic.evaluateHand(hand1) < ThreeCardLogic.evaluateHand(hand2));
    }

    @Test
    void testCompareHandsThreeOfAKindVsStraight() {
        // Three of a Kind
        hand1.add(new Card("hearts", "king"));
        hand1.add(new Card("diamonds", "king"));
        hand1.add(new Card("clubs", "king"));
        
        // Straight
        hand2.add(new Card("hearts", "7"));
        hand2.add(new Card("diamonds", "8"));
        hand2.add(new Card("clubs", "9"));
        
        assertTrue(ThreeCardLogic.evaluateHand(hand1) < ThreeCardLogic.evaluateHand(hand2));
    }

    @Test
    void testCompareHandsStraightVsFlush() {
        // Straight
        hand1.add(new Card("hearts", "7"));
        hand1.add(new Card("diamonds", "8"));
        hand1.add(new Card("clubs", "9"));
        
        // Flush
        hand2.add(new Card("hearts", "2"));
        hand2.add(new Card("hearts", "5"));
        hand2.add(new Card("hearts", "9"));
        
        assertTrue(ThreeCardLogic.evaluateHand(hand1) < ThreeCardLogic.evaluateHand(hand2));
    }

    @Test
    void testCompareHandsFlushVsPair() {
        // Flush
        hand1.add(new Card("hearts", "2"));
        hand1.add(new Card("hearts", "5"));
        hand1.add(new Card("hearts", "9"));
        
        // Pair
        hand2.add(new Card("hearts", "queen"));
        hand2.add(new Card("diamonds", "queen"));
        hand2.add(new Card("clubs", "5"));
        
        assertTrue(ThreeCardLogic.evaluateHand(hand1) < ThreeCardLogic.evaluateHand(hand2));
    }

    @Test
    void testCompareHandsPairVsHighCard() {
        // Pair
        hand1.add(new Card("hearts", "queen"));
        hand1.add(new Card("diamonds", "queen"));
        hand1.add(new Card("clubs", "5"));
        
        // High Card
        hand2.add(new Card("hearts", "king"));
        hand2.add(new Card("diamonds", "7"));
        hand2.add(new Card("clubs", "2"));
        
        assertTrue(ThreeCardLogic.evaluateHand(hand1) < ThreeCardLogic.evaluateHand(hand2));
    }
    
    @Test
    void testMixedSuitStraight() {
        hand1.add(new Card("hearts", "4"));
        hand1.add(new Card("diamonds", "5"));
        hand1.add(new Card("spades", "6"));
        assertEquals(3, ThreeCardLogic.evaluateHand(hand1));
    }

    @Test
    void testThreeOfAKindAces() {
        hand1.add(new Card("hearts", "ace"));
        hand1.add(new Card("diamonds", "ace"));
        hand1.add(new Card("clubs", "ace"));
        assertEquals(2, ThreeCardLogic.evaluateHand(hand1));
    }

    @Test
    void testPairWithHighCard() {
        hand1.add(new Card("hearts", "jack"));
        hand1.add(new Card("diamonds", "jack"));
        hand1.add(new Card("clubs", "ace"));
        assertEquals(5, ThreeCardLogic.evaluateHand(hand1));
    }

    @Test
    void testStraightFlushKingHigh() {
        hand1.add(new Card("spades", "jack"));
        hand1.add(new Card("spades", "queen"));
        hand1.add(new Card("spades", "king"));
        assertEquals(1, ThreeCardLogic.evaluateHand(hand1));
    }

    @Test
    void testFlushWithFaceCards() {
        hand1.add(new Card("diamonds", "king"));
        hand1.add(new Card("diamonds", "jack")); 
        hand1.add(new Card("diamonds", "2"));
        assertEquals(4, ThreeCardLogic.evaluateHand(hand1));
    }

    // Deck and Dealer Tests

    @Test
    void testDeckSize() {
        assertEquals(52, deck.getCards().size());
    }

    @Test
    void testDeckShuffle() {
        Deck deck2 = new Deck();
        deck.shuffle();
        assertNotEquals(deck.getCards(), deck2.getCards());
    }

    @Test
    void testDealerHandSize() {
        dealer.dealHand(deck);
        assertEquals(3, dealer.getHand().size());
    }

    @Test
    void testDeckSizeAfterDeal() {
        dealer.dealHand(deck);
        assertEquals(49, deck.getCards().size());
    }

    @Test
    void testUniqueCards() {
        ArrayList<Card> dealtCards = new ArrayList<>();
        for(int i = 0; i < 3; i++) {
            Card card = deck.getCards().get(i);
            assertFalse(dealtCards.contains(card));
            dealtCards.add(card);
        }
    }

    @Test
    void testDealerNewHand() {
        dealer.dealHand(deck);
        ArrayList<Card> firstHand = new ArrayList<>(dealer.getHand());
        dealer.dealHand(deck);
        assertNotEquals(firstHand, dealer.getHand());
    }

    @Test
    void testDeckReset() {
        dealer.dealHand(deck);
        deck = new Deck();
        assertEquals(52, deck.getCards().size());
    }

    @Test
    void testMultipleDeals() {
        dealer.dealHand(deck);
        dealer.dealHand(deck);
        assertEquals(46, deck.getCards().size());
    }

    @Test
    void testDealerHandValidity() {
        dealer.dealHand(deck);
        for(Card card : dealer.getHand()) {
            assertNotNull(card.getSuit());
            assertNotNull(card.getRank());
        }
    }

    @Test
    void testShuffledDeckValidity() {
        deck.shuffle();
        assertEquals(52, deck.getCards().size());
        for(Card card : deck.getCards()) {
            assertNotNull(card.getSuit());
            assertNotNull(card.getRank());
        }
    }
}