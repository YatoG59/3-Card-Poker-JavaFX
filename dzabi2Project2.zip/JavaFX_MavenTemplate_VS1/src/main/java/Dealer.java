import java.util.ArrayList;

public class Dealer {
    private ArrayList<Card> hand;

    public Dealer() {
        hand = new ArrayList<>();
    }

    public void dealHand(Deck deck) {
        hand.clear();
        for (int i = 0; i < 3; i++) {
            hand.add(deck.dealCard());
        }
    }

    public ArrayList<Card> getHand() {
        return hand;
    }
}