/**
 * Author: Denys Zabiyaka
 * NetID: dzabi2
 * Email: dzabi2@uic.edu
 * 
 * Description:
 * This project implements a JavaFX-based casino game "Three Card Poker" with support
 * for both single and two-player modes. The game features a complete poker hand 
 * evaluation system, betting mechanics (Ante and Pair Plus wagers), and dealer 
 * qualification rules following casino standards.
 */
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class JavaFXTemplate extends Application {

	@Override
	public void start(Stage primaryStage) throws Exception {
	    FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXML/WelcomeView.fxml"));
	    Parent root = loader.load();
	    
	    // Get controller and pass primary stage reference
	    MyController myController = loader.getController();
	    myController.setPrimaryStage(primaryStage);
	    // Set up scene and show stage
	    Scene scene = new Scene(root, 850, 850);
	    scene.getStylesheets().add(getClass().getResource("/styles/style1.css").toExternalForm());
	    primaryStage.setTitle("Three Card Poker");
	    primaryStage.setScene(scene);
	    primaryStage.show();
	}

    public static void main(String[] args) {
        launch(args); // Launches the JavaFX application
    }
}