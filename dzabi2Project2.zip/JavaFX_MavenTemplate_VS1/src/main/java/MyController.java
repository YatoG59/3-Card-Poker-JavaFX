/**
 * Author: Denys Zabiyaka
 * NetID: dzabi2
 * Email: dzabi2@uic.edu
 * 
 * Description:
 * This project implements a JavaFX-based casino game "Three Card Poker" with support
 * for both single and two-player modes. The game features a complete poker hand 
 * evaluation system, betting mechanics (Ante and Pair Plus wagers), and dealer 
 * qualification rules following casino standards.
 */
import javafx.animation.FadeTransition;
import javafx.animation.PauseTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.util.ArrayList;
import javafx.scene.layout.Pane;
import java.io.IOException;

public class MyController {
    private Player player1;
    private Player player2;
    private Dealer dealer;
    private Deck deck;
    private boolean isTwoPlayerMode = false;
    private boolean isOnePlayerMode = false;
    private Stage primaryStage;
    
    // Game state tracking
    private boolean betsPlacedPlayer1 = false;
    private boolean betsPlacedPlayer2 = false;
    private int antePlayer1 = 0;
    private int pairPlusPlayer1 = 0;
    private int antePlayer2 = 0;
    private int pairPlusPlayer2 = 0;
    private int totalWinsP1 = 0;
    private int totalWinsP2 = 0;
    private ArrayList<Card> hand;
    private boolean usingStyle1 = true;

    @FXML private TextArea gameInfo;
    @FXML private TextField anteBetField;
    @FXML private TextField pairPlusField;
    @FXML private Button dealButton, playButton, foldButton;
    @FXML private Button dealButton2, playButton2, foldButton2;
    @FXML private ImageView playerCard1, playerCard2, playerCard3;
    @FXML private ImageView playerCard12, playerCard22, playerCard32;
    @FXML private ImageView dealerCard1, dealerCard2, dealerCard3;
    @FXML private Label resultLabel;
    @FXML private Pane rootPane;
    @FXML private TextField anteBetField2;
    @FXML private TextField pairPlusField2;
    @FXML private Label betErrorLabel;
    @FXML private Label betErrorLabel2;
    @FXML private Label totalWinsLabel;
    @FXML private Label totalWinsLabel2;
    @FXML private Button placeBetsButton;
    @FXML private Button placeBetsButton2;

    public void setPrimaryStage(Stage stage) {
        this.primaryStage = stage;
    }

    private void displayCards(ImageView cardImageView1, ImageView cardImageView2, ImageView cardImageView3, ArrayList<Card> hand) {
        if (hand.isEmpty()) {
            cardImageView1.setImage(null);
            cardImageView2.setImage(null);
            cardImageView3.setImage(null);
            return;
        }
        
        cardImageView1.setImage(loadCardImage(hand.get(0)));
        cardImageView2.setImage(loadCardImage(hand.get(1)));
        cardImageView3.setImage(loadCardImage(hand.get(2)));
    }

    private void hideDealerCards() {
        dealerCard1.setImage(new Image("/images/card_back_blue.png"));
        dealerCard2.setImage(new Image("/images/card_back_blue.png"));
        dealerCard3.setImage(new Image("/images/card_back_blue.png"));
    }
    private void hidePlayer1Cards() {
        playerCard1.setImage(new Image("/images/card_back_blue.png"));
        playerCard2.setImage(new Image("/images/card_back_blue.png"));
        playerCard3.setImage(new Image("/images/card_back_blue.png"));
    }
    private void hidePlayer2Cards() {
        playerCard12.setImage(new Image("/images/card_back_blue.png"));
        playerCard22.setImage(new Image("/images/card_back_blue.png"));
        playerCard32.setImage(new Image("/images/card_back_blue.png"));
    }
    
    private void revealPlayer1Cards() {
        displayCards(playerCard1, playerCard2, playerCard3, player1.getHand());
    }
    private void revealPlayer2Cards() {
        displayCards(playerCard12, playerCard22, playerCard32, player2.getHand());
    }
    private void revealDealerCards() {
        displayCards(dealerCard1, dealerCard2, dealerCard3, dealer.getHand());
    }

    private void resetForNextRound() {
        disableAllExceptDeal();
        hidePlayer1Cards();
        if (isTwoPlayerMode) {
        	hidePlayer2Cards();
        }
        hideDealerCards();
        betsPlacedPlayer1 = false;
        betsPlacedPlayer2 = false;
        anteBetField.clear();
        pairPlusField.clear();
        if (isTwoPlayerMode) {
            anteBetField2.clear();
            pairPlusField2.clear();
        }
    }

    @FXML
    public void initialize() {
        deck = new Deck();
        dealer = new Dealer();
        player1 = new Player(100);
    }

    private void disableAllExceptDeal() {
        dealButton.setDisable(false);
        anteBetField.setDisable(true);
        pairPlusField.setDisable(true);
        placeBetsButton.setDisable(true);
        playButton.setDisable(true);
        foldButton.setDisable(true);
        anteBetField2.setDisable(true);
        pairPlusField2.setDisable(true);
        placeBetsButton2.setDisable(true);
        playButton2.setDisable(true);
        foldButton2.setDisable(true);
        dealButton2.setDisable(false);
        }
    
    public void setOnePlayerMode(boolean mode) {
        this.isOnePlayerMode = mode;
        player1 = new Player(100);
        updateTotalWins();
        dealButton.setDisable(false);
        anteBetField.setDisable(true);
        pairPlusField.setDisable(true);
        placeBetsButton.setDisable(true);
        playButton.setDisable(true);
        foldButton.setDisable(true);
        
    }
    	
    public void setTwoPlayerMode(boolean mode) {
        this.isTwoPlayerMode = mode;
        // Initialize player 2 if in two-player mode
        if (isTwoPlayerMode && player2 == null) {
            player2 = new Player(100);
        }
        updateTotalWins();
        dealButton.setDisable(false);
        anteBetField.setDisable(true);
        pairPlusField.setDisable(true);
        placeBetsButton.setDisable(true);
        playButton.setDisable(true);
        foldButton.setDisable(true);
        // Initialize UI elements for two-player mode if needed
        if (isTwoPlayerMode) {
            if (dealButton2 != null) dealButton2.setDisable(false);
            if (anteBetField2 != null) anteBetField2.setDisable(true);
            if (pairPlusField2 != null) pairPlusField2.setDisable(true);
            if (placeBetsButton2 != null) placeBetsButton2.setDisable(true);
            if (playButton2 != null) playButton2.setDisable(true);
            if (foldButton2 != null) foldButton2.setDisable(true);
        }
    }

    private void validateAndPlaceBets(TextField anteBetField, TextField pairPlusField, Label errorLabel) {
        String anteText = anteBetField.getText();
        String pairPlusText = pairPlusField.getText();
        if (anteText.isEmpty()) {
            throw new IllegalArgumentException("Ante bet is required");
        }
        
        int anteBet = Integer.parseInt(anteText);
        if (anteBet < 5 || anteBet > 25) {
            throw new IllegalArgumentException("Ante bet must be between $5 and $25");
        }
        
        int pairPlusBet = 0;
        if (!pairPlusText.isEmpty()) {
            pairPlusBet = Integer.parseInt(pairPlusText);
            if (pairPlusBet < 5 || pairPlusBet > 25) {
                throw new IllegalArgumentException("Pair Plus bet must be between $5 and $25");
            }
        }
        
        antePlayer1 = anteBet;
        pairPlusPlayer1 = pairPlusBet;
        player1.updateBalance(-(anteBet + pairPlusBet));
        
        if (isTwoPlayerMode) {
        	String anteText2 = anteBetField2.getText();
            String pairPlusText2 = pairPlusField2.getText();
            if (anteText.isEmpty()) {
                throw new IllegalArgumentException("Ante bet is required");
            }
            
            int anteBet2 = Integer.parseInt(anteText2);
            if (anteBet2 < 5 || anteBet2 > 25) {
                throw new IllegalArgumentException("Ante bet must be between $5 and $25");
            }
            
            int pairPlusBet2 = 0;
            if (!pairPlusText2.isEmpty()) {
                pairPlusBet2 = Integer.parseInt(pairPlusText2);
                if (pairPlusBet2 < 5 || pairPlusBet2 > 25) {
                    throw new IllegalArgumentException("Pair Plus bet must be between $5 and $25");
                }
            }
            antePlayer2 = anteBet2;
            pairPlusPlayer2 = pairPlusBet2;
            player2.updateBalance(-(anteBet2 + pairPlusBet2)); 
        }
        
        anteBetField.setDisable(true);
        pairPlusField.setDisable(true);
        errorLabel.setText("");
        updateGameInfo();
    }

    @FXML
    public void dealCards() {
        updateTotalWins();
        deck.shuffle();
        dealer.dealHand(deck);
        player1.dealHand(deck);
        dealButton.setDisable(true);
        anteBetField.setDisable(false);
        pairPlusField.setDisable(false);
        placeBetsButton.setDisable(false);
        hidePlayer1Cards();
        hideDealerCards();
        gameInfo.setText("Cards dealt. Place your bets.");
    }

    @FXML
    public void dealCards2() {
        updateTotalWins();
        deck.shuffle();
        dealer.dealHand(deck);
        player2.dealHand(deck);
        dealButton2.setDisable(true);
        anteBetField2.setDisable(false);
        pairPlusField2.setDisable(false);
        placeBetsButton2.setDisable(false);
        hidePlayer2Cards();
        hideDealerCards();
        gameInfo.setText("Player 2 Cards dealt. Place your bets.");
    }

    @FXML
    public void placeBets() {
        try {
            String anteText = anteBetField.getText();
            if (anteText.isEmpty()) {
                betErrorLabel.setText("Ante bet is required");
                return;
            }
            
            int anteBet = Integer.parseInt(anteText);
            if (anteBet < 5 || anteBet > 25) {
                betErrorLabel.setText("Ante bet must be between $5 and $25");
                return;
            }
            
            int pairPlusBet = 0;
            if (!pairPlusField.getText().isEmpty()) {
                pairPlusBet = Integer.parseInt(pairPlusField.getText());
                if (pairPlusBet < 5 || pairPlusBet > 25) {
                    betErrorLabel.setText("Pair Plus bet must be between $5 and $25");
                    return;
                }
            }
            revealPlayer1Cards();
            antePlayer1 = anteBet;
            pairPlusPlayer1 = pairPlusBet;
            player1.updateBalance(-(anteBet + pairPlusBet));
            anteBetField.setDisable(true);
            pairPlusField.setDisable(true);
            placeBetsButton.setDisable(true);
            playButton.setDisable(false);
            foldButton.setDisable(false);
            betsPlacedPlayer1 = true;
            updateGameInfo();
            updateTotalWins();
        } catch (NumberFormatException e) {
            betErrorLabel.setText("Please enter valid numbers");
        }
    }

    @FXML
    public void placeBets2() {
        try {
            String anteText2 = anteBetField2.getText();
            if (anteText2.isEmpty()) {
                betErrorLabel2.setText("Ante bet is required");
                return;
            }
            
            int anteBet2 = Integer.parseInt(anteText2);
            if (anteBet2 < 5 || anteBet2 > 25) {
                betErrorLabel.setText("Ante bet must be between $5 and $25");
                return;
            }
            
            int pairPlusBet2 = 0;
            if (!pairPlusField2.getText().isEmpty()) {
                pairPlusBet2 = Integer.parseInt(pairPlusField.getText());
                if (pairPlusBet2 < 5 || pairPlusBet2 > 25) {
                    betErrorLabel.setText("Pair Plus bet must be between $5 and $25");
                    return;
                }
            }
            revealPlayer2Cards();
            antePlayer2 = anteBet2;
            pairPlusPlayer2 = pairPlusBet2;
            player2.updateBalance(-(anteBet2 + pairPlusBet2));
            anteBetField2.setDisable(true);
            pairPlusField2.setDisable(true);
            placeBetsButton2.setDisable(true);
            playButton2.setDisable(false);
            foldButton2.setDisable(false);
            betsPlacedPlayer2 = true;
            updateGameInfo();
            updateTotalWins();
        } catch (NumberFormatException e) {
            betErrorLabel2.setText("Please enter valid numbers");
        }

    }

    @FXML
    public void playHand() {
        // Play wager is equal to ante wager
        int playBet = antePlayer1;
        player1.updateBalance(-playBet);  // Deduct play wager
        
        int playerResult = ThreeCardLogic.evaluateHand(player1.getHand());
        int dealerResult = ThreeCardLogic.evaluateHand(dealer.getHand());
        
        // Handle Pair Plus first if bet was made
        if (pairPlusPlayer1 > 0) {
            handlePairPlusPayout(player1, playerResult, pairPlusPlayer1);
        }
        
        // Check dealer qualification
        if (!dealerQualifies(dealer.getHand())) {
            player1.updateBalance(playBet);  // Return play wager
            // Ante is pushed to next hand (no action needed)
            gameInfo.setText("Dealer doesn't qualify with Queen high or better. Play bet returned, Ante pushed.");
        } else {
            handleAntePayout(player1, playerResult, dealerResult, antePlayer1, playBet);
        }
        
        // Disable buttons and update UI
        playButton.setDisable(true);
        foldButton.setDisable(true);
        dealButton.setDisable(false);
        
        // Show dealer's cards if appropriate
        if (!isTwoPlayerMode || (playButton2.isDisabled() && foldButton2.isDisabled())) {
            revealDealerCards();
        }
        
    }

    @FXML
    public void playHand2() {
        if (!isTwoPlayerMode) return;
        
        // Play wager is equal to ante wager
        int playBet2 = antePlayer2;
        player2.updateBalance(-playBet2);  // Deduct play wager
        
        int playerResult = ThreeCardLogic.evaluateHand(player2.getHand());
        int dealerResult = ThreeCardLogic.evaluateHand(dealer.getHand());
        
        // Handle Pair Plus first if bet was made
        if (pairPlusPlayer2 > 0) {
            handlePairPlusPayout(player2, playerResult, pairPlusPlayer2);
        }
        
        // Check dealer qualification
        if (!dealerQualifies(dealer.getHand())) {
            player2.updateBalance(playBet2);  // Return play wager
            // Ante is pushed to next hand (no action needed)
            gameInfo.setText("Dealer doesn't qualify with Queen high or better. Play bet returned, Ante pushed.");
        } else {
            handleAntePayout(player2, playerResult, dealerResult, antePlayer2, playBet2);
        }
        
        // Disable buttons and update UI
        playButton2.setDisable(true);
        foldButton2.setDisable(true);
        dealButton2.setDisable(false);
        
        // Show dealer's cards if both players have acted
        if (playButton.isDisabled() && foldButton.isDisabled()) {
            revealDealerCards();
        }
        
    }

    @FXML
    public void foldHand() {
        // When folding, player loses ante and pair plus bets (already deducted)
        gameInfo.setText("Player 1 folds. Loses Ante bet of $" + antePlayer1 + 
                        (pairPlusPlayer1 > 0 ? " and Pair Plus bet of $" + pairPlusPlayer1 : ""));
        
        playButton.setDisable(true);
        foldButton.setDisable(true);
        dealButton.setDisable(false);
        
        if (!isTwoPlayerMode || (playButton2.isDisabled() && foldButton2.isDisabled())) {
            revealDealerCards();
        }
    }

    @FXML
    public void foldHand2() {
        if (!isTwoPlayerMode) return;
        
        // When folding, player loses ante and pair plus bets (already deducted)
        gameInfo.setText("Player 2 folds. Loses Ante bet of $" + antePlayer2 + 
                        (pairPlusPlayer2 > 0 ? " and Pair Plus bet of $" + pairPlusPlayer2 : ""));
        
        playButton2.setDisable(true);
        foldButton2.setDisable(true);
        dealButton2.setDisable(false);
        
        // Show dealer's cards if both players have acted
        if (playButton.isDisabled() && foldButton.isDisabled()) {
            revealDealerCards();
        }
    }

    private boolean dealerQualifies(ArrayList<Card> hand) {
        for (Card card : hand) {
            if (card.getRank().equals("queen") ||
                card.getRank().equals("king") ||
                card.getRank().equals("ace")) {
                return true;
            }
        }
        return false;
    }

    private void handlePairPlusPayout(Player player, int handRank, int pairPlusBet) {
        String playerName = (player == player1) ? "Player 1" : "Player 2";
        StringBuilder message = new StringBuilder();
        
        switch (handRank) {
            case 1: // Straight Flush
                player.updateBalance(pairPlusBet * 41);  // 40 to 1 payout
                message.append(playerName).append(" wins Pair Plus with Straight Flush!");
                break;
            case 2: // Three of a Kind
                player.updateBalance(pairPlusBet * 31);  // 30 to 1 payout
                message.append(playerName).append(" wins Pair Plus with Three of a Kind!");
                break;
            case 3: // Straight
                player.updateBalance(pairPlusBet * 7);   // 6 to 1 payout
                message.append(playerName).append(" wins Pair Plus with Straight!");
                break;
            case 4: // Flush
                player.updateBalance(pairPlusBet * 4);   // 3 to 1 payout
                message.append(playerName).append(" wins Pair Plus with Flush!");
                break;
            case 5: // Pair
                player.updateBalance(pairPlusBet * 2);   // 1 to 1 payout
                message.append(playerName).append(" wins Pair Plus with Pair!");
                break;
            default:
                message.append(playerName).append(" loses Pair Plus");
                break;
        }
        
        gameInfo.setText(message.toString());
        updateTotalWins();
    }

    private void handleAntePayout(Player player, int playerRank, int dealerRank, int anteBet, int playBet) {
        StringBuilder message = new StringBuilder();
        String playerName = (player == player1) ? "Player 1" : "Player 2";
        
        if (playerRank < dealerRank) {
            // Player wins
            player.updateBalance(anteBet * 2 + playBet * 2);  // Double both ante and play wagers
            message.append(playerName).append(" beats dealer!");
        } else if (playerRank > dealerRank) {
            // Dealer wins - player loses both ante and play wagers (already deducted)
            message.append(playerName).append(" loses to dealer");
        } else {
            // Push - return both ante and play wagers
            player.updateBalance(anteBet + playBet);
            message.append("Push between ").append(playerName).append(" and dealer!");
        }
        
        gameInfo.setText(message.toString());
        updateTotalWins();
    }

    private void updateGameInfo() {
        StringBuilder info = new StringBuilder();
        info.append("Player 1 bets: Ante=$").append(antePlayer1);
        if (pairPlusPlayer1 > 0) {
            info.append(", Pair Plus=$").append(pairPlusPlayer1);
        }
        if (isTwoPlayerMode && betsPlacedPlayer2) {
            info.append("\nPlayer 2 bets: Ante=$").append(antePlayer2);
            if (pairPlusPlayer2 > 0) {
                info.append(", Pair Plus=$").append(pairPlusPlayer2);
            }
        }
        gameInfo.setText(info.toString());
    }

    private void updateTotalWins() {
        if (totalWinsLabel != null) {
            totalWinsLabel.setText("Total Wins: $" + player1.getBalance());
        }
        if (isTwoPlayerMode && totalWinsLabel2 != null) {
            totalWinsLabel2.setText("Total Wins: $" + player2.getBalance());
        }
    }
    private Image loadCardImage(Card card) {
        String imageName = card.getRank().toLowerCase() + "_of_" + card.getSuit().toLowerCase() + ".png";
        return new Image("/images/" + imageName);
    }

    @FXML
    public void newLook() {
        try {
            Scene scene = rootPane.getScene();
            // Clear existing stylesheets
            scene.getStylesheets().clear();
            // Toggle between styles
            if (usingStyle1) {
                scene.getStylesheets().add(getClass().getResource("/styles/style2.css").toExternalForm());
                usingStyle1 = false;
            } else {
                scene.getStylesheets().add(getClass().getResource("/styles/style1.css").toExternalForm());
                usingStyle1 = true;
            }
        } catch (Exception e) {
            System.out.println("Error changing style: " + e.getMessage());
        }
    }

    @FXML
    public void freshStart() {
        // Reset players' balances
        player1 = new Player(100);
        if (isTwoPlayerMode) {
            player2 = new Player(100);
        }
        // Reset game state
        betsPlacedPlayer1 = false;
        betsPlacedPlayer2 = false;
        antePlayer1 = 0;
        pairPlusPlayer1 = 0;
        antePlayer2 = 0;
        pairPlusPlayer2 = 0;
        // Reset UI elements
        resetUIElements();
        // Reset deck and dealer
        deck = new Deck();
        dealer = new Dealer();
        // Update display
        updateGameInfo();
        updateTotalWins();
        // Set initial button states
        setInitialButtonStates();
    }

    private void setInitialButtonStates() {
        // Enable only Deal button
        dealButton.setDisable(false);
        // Disable all other controls
        anteBetField.setDisable(true);
        pairPlusField.setDisable(true);
        placeBetsButton.setDisable(true);
        playButton.setDisable(true);
        foldButton.setDisable(true);
        if (isTwoPlayerMode) {
            dealButton2.setDisable(false);
            anteBetField2.setDisable(true);
            pairPlusField2.setDisable(true);
            placeBetsButton2.setDisable(true);
            playButton2.setDisable(true);
            foldButton2.setDisable(true);
        }
    }

    private void resetUIElements() {
        // Clear all fields
        anteBetField.clear();
        pairPlusField.clear();
        // Clear cards
        displayCards(playerCard1, playerCard2, playerCard3, new ArrayList<>());
        hideDealerCards();
        // Reset labels
        if (totalWinsLabel != null) totalWinsLabel.setText("Total Wins: $0");
        if (gameInfo != null) gameInfo.setText("Welcome to Three Card Poker!\nPlace your bets to begin.");
        if (isTwoPlayerMode) {
            // Reset Player 2 elements
            anteBetField2.clear();
            pairPlusField2.clear();
            if (totalWinsLabel2 != null) totalWinsLabel2.setText("Total Wins: $0");
            displayCards(playerCard12, playerCard22, playerCard32, new ArrayList<>());
        }
        // Set initial button states
        setInitialButtonStates();
    }

    @FXML
    public void startGame1() throws Exception {
        if (primaryStage == null) {
            System.out.println("Error: Primary stage is null");
            return;
        }
        
        // Load PlayerSelection.fxml
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXML/PlayerSelection.fxml"));
        Parent root = loader.load();
        
        // Get SelectPlayer controller and pass primary stage reference
        SelectPlayer selectPlayerController = loader.getController();
        selectPlayerController.setPrimaryStage(primaryStage);
        
        Scene scene = new Scene(root, 850, 850);
        scene.getStylesheets().add(getClass().getResource("/styles/style1.css").toExternalForm());
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    @FXML
    public void exitGame() throws Exception {
        // Load WelcomeView.fxml
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXML/WelcomeView.fxml"));
        Parent root = loader.load();
        
        // Get the new controller and pass the stage reference
        MyController newController = loader.getController();
        newController.setPrimaryStage(primaryStage);
        
        Scene scene = new Scene(root, 850, 850);
        scene.getStylesheets().add(getClass().getResource("/styles/style1.css").toExternalForm());
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    @FXML
    public void exit() {
        primaryStage.close(); // Close the application
    }
}