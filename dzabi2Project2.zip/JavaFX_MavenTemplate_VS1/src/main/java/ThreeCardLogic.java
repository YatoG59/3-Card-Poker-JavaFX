import java.util.ArrayList;
import java.util.HashMap;

public class ThreeCardLogic {

    // Method to evaluate a player's hand and return a ranking
    public static int evaluateHand(ArrayList<Card> hand) {
        if (isStraightFlush(hand)) {
            return 1; // Straight Flush
        } else if (isThreeOfAKind(hand)) {
            return 2; // Three of a Kind
        } else if (isStraight(hand)) {
            return 3; // Straight
        } else if (isFlush(hand)) {
            return 4; // Flush
        } else if (isPair(hand)) {
            return 5; // Pair
        } else {
            return 6; // High Card
        }
    }

    // Helper method to check if the hand is a Straight Flush
    private static boolean isStraightFlush(ArrayList<Card> hand) {
        return isFlush(hand) && isStraight(hand);
    }

    // Helper method to check if the hand is Three of a Kind
    private static boolean isThreeOfAKind(ArrayList<Card> hand) {
        String rank1 = hand.get(0).getRank();
        String rank2 = hand.get(1).getRank();
        String rank3 = hand.get(2).getRank();
        
        return rank1.equals(rank2) && rank2.equals(rank3);
    }

    // Helper method to check if the hand is a Straight
    private static boolean isStraight(ArrayList<Card> hand) {
        HashMap<String, Integer> rankValues = getRankValues();
        
        ArrayList<Integer> values = new ArrayList<>();
        for (Card card : hand) {
            values.add(rankValues.get(card.getRank()));
        }
        
        values.sort(Integer::compareTo);
        
        // Check for normal straight (e.g., 4-5-6)
        boolean normalStraight = (values.get(2) - values.get(1) == 1) && (values.get(1) - values.get(0) == 1);
        
        // Check for special case Ace-low straight (e.g., A-2-3)
        boolean aceLowStraight = values.contains(14) && values.contains(2) && values.contains(3);
        
        return normalStraight || aceLowStraight;
    }

    // Helper method to check if the hand is a Flush
    private static boolean isFlush(ArrayList<Card> hand) {
        String suit1 = hand.get(0).getSuit();
        
        for (Card card : hand) {
            if (!card.getSuit().equals(suit1)) {
                return false;
            }
        }
        
        return true;
    }

    // Helper method to check if the hand is a Pair
    private static boolean isPair(ArrayList<Card> hand) {
        String rank1 = hand.get(0).getRank();
        String rank2 = hand.get(1).getRank();
        String rank3 = hand.get(2).getRank();
        
        return rank1.equals(rank2) || rank2.equals(rank3) || rank1.equals(rank3);
    }

    // Helper method to get the rank values for comparison
    private static HashMap<String, Integer> getRankValues() {
        HashMap<String, Integer> rankValues = new HashMap<>();
        
        rankValues.put("2", 2);
        rankValues.put("3", 3);
        rankValues.put("4", 4);
        rankValues.put("5", 5);
        rankValues.put("6", 6);
        rankValues.put("7", 7);
        rankValues.put("8", 8);
        rankValues.put("9", 9);
        rankValues.put("10", 10);
        rankValues.put("jack", 11);
        rankValues.put("queen", 12);
        rankValues.put("king", 13);
        rankValues.put("ace", 14); // Ace is high
        
        return rankValues;
    }
}