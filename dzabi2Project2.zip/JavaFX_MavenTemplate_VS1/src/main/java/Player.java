import java.util.ArrayList;

public class Player {
    private ArrayList<Card> hand;
    private int balance;
    
    public Player(int balance) {
        this.balance = balance;
        hand = new ArrayList<>();
    }

    public void dealHand(Deck deck) {
        hand.clear();
        for (int i = 0; i < 3; i++) {
            hand.add(deck.dealCard());
        }
    }

    public ArrayList<Card> getHand() {
        return hand;
    }

    public int getBalance() {
        return balance;
    }

    public void updateBalance(int amount) {
        balance += amount;
    }
}