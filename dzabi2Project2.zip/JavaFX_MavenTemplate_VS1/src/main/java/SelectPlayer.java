import javafx.animation.FadeTransition;
import javafx.animation.PauseTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.util.ArrayList;
import java.io.IOException;

public class SelectPlayer {

    private Stage primaryStage;
    private boolean isTwoPlayerMode = false;
    private boolean isOnePlayerMode = false;
    
    // Method to set the primary stage from JavaFXTemplate
    public void setPrimaryStage(Stage stage) {
        this.primaryStage = stage;
    }
    @FXML
    public void selectSinglePlayer() throws Exception {
    	isTwoPlayerMode = false;
        // Load GameView_OnePlayer.fxml and switch scene
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXML/GameView_OnePlayer.fxml"));
        Parent root = loader.load();
         
        // Pass primary stage reference to MyController
        MyController myController = loader.getController();
        myController.setPrimaryStage(primaryStage);
        myController.setOnePlayerMode(true);
        myController.setTwoPlayerMode(false);
        
        Scene scene = new Scene(root, 850, 850);
        scene.getStylesheets().add(getClass().getResource("/styles/style1.css").toExternalForm());
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    @FXML
    public void selectTwoPlayers() throws Exception {
    	isTwoPlayerMode = true;
        // Load GameView_TwoPlayers.fxml and switch scene
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXML/GameView_TwoPlayers.fxml"));
        Parent root = loader.load();
        
        // Get controller and pass primary stage reference
        MyController myController = loader.getController();
        myController.setPrimaryStage(primaryStage);
        myController.setOnePlayerMode(false);
        myController.setTwoPlayerMode(true);
        
        Scene scene = new Scene(root, 850, 850);
        scene.getStylesheets().add(getClass().getResource("/styles/style1.css").toExternalForm());
        primaryStage.setScene(scene);
        primaryStage.show();
    }

}